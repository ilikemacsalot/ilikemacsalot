#import <Cocoa/Cocoa.h>

@interface RMHTML : NSObject {
	
	BOOL _allowWebUnsafeFonts;
	NSDictionary* _currentMarkupAttribute;
	NSString* _filesFolderName;
	NSString* _imagesFolderName;
	NSString* _assetsFolderName;
}

- (BOOL)allowWebUnsafeFonts;
- (void)setAllowWebUnsafeFonts:(BOOL)flag;

- (NSString *)exportAttributedString:(NSAttributedString *)str
							  toPath:(NSString *)path
						imagesFolder:(NSString *)imagesFolder
						 imagePrefix:(NSString *)imagePrefix
						HTMLTemplate:(NSMutableString *)theTemplate
						  contentTag:(NSString *)contentTag;

- (NSString *)exportAttributedString:(NSAttributedString *)str
							  toPath:(NSString *)path
						imagesFolder:(NSString *)imagesFolder
						 imagePrefix:(NSString *)imagePrefix
						HTMLTemplate:(NSMutableString *)theTemplate
						  contentTag:(NSString *)contentTag
							fromPage:(id)thePage;

- (NSString *)exportAttributedString:(NSAttributedString *)str
							  toPath:(NSString *)path
						imagesFolder:(NSString *)imagesFolder
						 imagePrefix:(NSString *)imagePrefix
						HTMLTemplate:(NSMutableString *)theTemplate
						  contentTag:(NSString *)contentTag
							fromPage:(id)thePage
					 depthCorrection:(int)depthCorrection;

- (NSString*)filesFolderName;
- (void)setFilesFolderName:(NSString*)name;
- (NSString*)imagesFolderName;
- (void)setImagesFolderName:(NSString*)name;
- (NSString*)assetsFolderName;
- (void)setAssetsFolderName:(NSString*)name;

@end