/*
    RWAbstractPlugin.h
    RapidWeaver Plugin Development Kit

    Copyright (c) 2004 Realmac Software Limited. All rights reserved.
*/

#import <Cocoa/Cocoa.h>

@class RMHTML;
@protocol RWPluginProtocol;

@interface RWAbstractPlugin : NSObject <RWPluginProtocol, NSCoding>
{
    NSWindow *_documentWindow;
    NSMutableDictionary *_themeSpecificOptionsDictionary;
    NSString *_uniqueID;
    id _document;
}

- (id)document;
- (void)setDocument:(id)document;

- (NSWindow *)documentWindow;
- (void)setDocumentWindow:(NSWindow *)documentWindow;

- (NSString*)documentPath;

- (NSString *)uniqueID;
- (void)setUniqueID:(NSString *)uniqueID;

+ (NSArray *)extraFilesNeededInExportFolder:(NSDictionary*)params;
- (NSArray *)extraFilesNeededInExportFolder:(NSDictionary*)params;

- (NSString *)contentHTML:(NSDictionary*)params;
- (NSString *)sidebarHTML:(NSDictionary*)params;

- (void)broadcastPluginChanged;
- (void)broadcastPluginChangedInvert;
- (void)broadcastPluginExportStatus:(NSString*)message progress:(float)percent;
- (void)broadcastMediaChanged;

- (NSArray*)directoryContents:(NSString*)path;

- (NSString*)tempFilesDirectory:(NSString*)name;
+ (NSString*)tempFilesDirectory:(NSString*)name forPlugin:(RWAbstractPlugin*)plugin;
+ (NSString*)tempFilesDirectory:(NSString*)name forUniqueID:(NSString*)unique;

+ (NSString*)rwTempFilesDirectory;
+ (NSString*)appTempFilesDirectory;

- (RMHTML*)exporterWithParams:(NSDictionary*)params;
- (NSString*)pathToThemeFile:(NSString*)file params:(NSDictionary*)params correction:(int)depth;

- (NSMutableDictionary*)pluginSettingsValueForDisplay:(NSString*)display value:(id)value;

- (NSMutableString*)updatePageTemplate:(NSMutableString*)template params:(NSDictionary*)params depth:(int)depth;

@end