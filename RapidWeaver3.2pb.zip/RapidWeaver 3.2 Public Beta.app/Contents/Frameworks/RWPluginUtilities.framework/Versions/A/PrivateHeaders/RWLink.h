//
//  RWLink.h
//  RWPluginUtilities
//
//  Created by Simon Taylor on 20/02/2005.
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>


@interface RWLink : NSObject {

	NSString* _href;
	NSString* _anchor;
	NSString* _name;
	NSString* _target;
	BOOL _internal;
	int _asset;
	
	// ...plus many others...
	
}

enum {
	kRWLinkNotAnAsset = 0,
	kRWLinkPageAsset = 1,
	kRWLinkSiteAsset = 2
};

- (id)initWithHREF:(NSString*)link internal:(BOOL)internal;

- (NSString*)href;
- (void)setHREF:(NSString*)href;
- (NSString*)anchor;
- (void)setAnchor:(NSString*)anchor;
- (NSString*)name;
- (void)setName:(NSString*)name;
- (NSString*)target;
- (void)setTarget:(NSString*)target;
- (BOOL)internal;
- (void)setInternal:(BOOL)flag;
- (int)asset;
- (void)setAsset:(int)asset;

@end
