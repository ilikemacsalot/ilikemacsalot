//
//  RWQTExport.h
//  RWPluginUtilities
//
//  Created by Simon Taylor on Tue Aug 24 2004.
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Foundation/Foundation.h>
#import <QuickTime/QuickTime.h>

@interface RWQTExport : NSObject {
	NSString* _path;
	NSString* _source;
	NSData* _data;
	NSColor* _fillColour;
	OSType _format;
	CodecQ _quality;
	ComponentInstance _importer;
	ComponentInstance _exporter;
	OSStatus _status;
	float _width, _height;
	BOOL _hqScaling:1;
	BOOL _retainProfiles:1;
	BOOL _flipHorizontally:1;
	BOOL _flipVertically:1;
	BOOL _clip:1;
	float _rotation;
	NSData* _tiff;
}

- (id)initWithData:(NSData*)data;
//- (id)initWithFile:(NSString*)path;

- (id)initWithPath:(NSString*)path;

+ (id)exporterWithData:(NSData*)data;
+ (id)exporterWithFile:(NSString*)path;

- (void)setDestination:(NSString*)path;
- (void)setFormat:(OSType)format;
- (void)setQuality:(CodecQ)quality;
- (void)setWidth:(float)width;
- (void)setHeight:(float)height;

- (BOOL)highQualityScaling;
- (void)setHighQualityScaling:(BOOL)flag;

- (BOOL)retainProfiles;
- (void)setRetainProfiles:(BOOL)flag;

- (BOOL)flipHorizontally;
- (void)setFlipHorizontally:(BOOL)flag;

- (BOOL)flipVertically;
- (void)setFlipVertically:(BOOL)flag;

- (float)rotation;
- (void)setRotation:(float)rotation;

- (BOOL)clip;
- (void)setClip:(BOOL)clip;

- (NSColor*)fillColour;
- (void)setFillColour:(NSColor*)colour;

- (OSStatus)export;

+ (ImageDescriptionHandle)getImageDescription:(NSString*)path;

+ (NSSize)getMovieDimensions:(NSString*)path;
+ (NSString*)quicktimeEmbedHTMLForSrc:(NSString*)path width:(int)width height:(int)height autoplay:(BOOL)autoplay;

@end
