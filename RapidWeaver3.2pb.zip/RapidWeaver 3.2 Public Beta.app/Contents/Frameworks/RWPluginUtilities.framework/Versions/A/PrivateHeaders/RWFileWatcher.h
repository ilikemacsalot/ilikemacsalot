//
//  RWFileWatcher.h
//  RWPluginUtilities
//
//  Created by Simon Taylor on 13/08/2005.
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>

@protocol RWFileWatcherDelegate
- (void)watchedFileDidChange:(NSString*)path;
- (void)watchedFileWasRenamed:(NSString*)path;
- (void)watchedFileWasDeleted:(NSString*)path;
@end

@interface RWFileWatcher : NSObject {
	NSMutableArray* _files;
	BOOL _keepWatching:1;
	BOOL _watcherRunning:1;
	id<RWFileWatcherDelegate> _delegate;
}

+ (RWFileWatcher*)watcherWithDelegate:(id<RWFileWatcherDelegate>)delegate;

- (void)setDelegate:(id<RWFileWatcherDelegate>)delegate;

- (BOOL)addFile:(NSString*)path;
- (void)removeFile:(NSString*)path;
- (void)stop;

@end

@interface RWFolderWatcher : RWFileWatcher {

	NSString* _folder;
}

- (NSString*)folder;

- (BOOL)addFolder:(NSString*)path;
- (void)removeFolder:(NSString*)path;
- (BOOL)refreshFolder;

@end
