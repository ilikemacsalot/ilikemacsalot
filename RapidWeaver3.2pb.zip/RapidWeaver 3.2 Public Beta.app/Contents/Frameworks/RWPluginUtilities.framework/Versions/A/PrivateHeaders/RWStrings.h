//
//  RWStrings.h
//  RWPluginUtilities
//
//  Created by Simon Taylor on 21/02/2005.
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>


@interface NSString (RWStringUtilities)
- (NSMutableString*)stripRepeatedPathSeparators;
- (BOOL)validWebFilename;
- (NSString*)convertToEntities;
- (NSString*)convertToNumericalReferences:(BOOL)everything;
- (NSString*)summarizeToSentences:(UInt32*)sentences;
@end

@interface NSMutableString (RWStringUtilities)
- (void)appendForwardSlash;
@end

@interface NSAttributedString (RWStringUtilities)
- (NSArray*)attachments;
@end

@interface NSString (RWPathUtilities)
- (NSString*)resolveAliases;
- (OSStatus)pathToFSRef:(FSRef*)fsRef;
- (OSStatus)pathToFSSpec:(FSSpec*)spec;
- (NSMutableData*)aliasForPathRelativeTo:(NSString*)pathB;
@end

@interface NSString (MD5_Checksum)
- (NSData*)md5Checksum;
@end

@interface NSMutableData (RWPathUtilities)
- (NSString*)resolveAliasRelativeTo:(NSString*)pathB withoutUI:(BOOL)flag;
@end
