//
//  RWExportParams.h
//  RWPluginUtilities
//
//  Created by Simon Taylor on 13/08/2005.
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>


@interface NSDictionary (RWExportParams)

- (NSString*)exportMode;
- (BOOL)isPreviewExportMode;
- (BOOL)isExportExportMode;
- (BOOL)isPublishExportMode;

- (NSString*)exportFilename;
- (NSString*)exportPageTitle;
- (NSString*)exportPagePath;
- (NSString*)exportPageLocation;

- (NSString*)exportFilesFolderName;
- (NSString*)exportImagesFolderName;
- (NSString*)exportAssetsFolderName;

- (NSDictionary*)exportPageAttributes;

- (NSString*)exportSiteIndexFilename;

- (NSString*)exportPathToCommonThemeFiles;
- (NSString*)exportPathToCommonPluginFiles;

- (BOOL)exportCommonPathsAreRelatve;
- (BOOL)exportCommonPathsAreAbsolute;

- (NSString*)exportSiteBaseURL;

@end