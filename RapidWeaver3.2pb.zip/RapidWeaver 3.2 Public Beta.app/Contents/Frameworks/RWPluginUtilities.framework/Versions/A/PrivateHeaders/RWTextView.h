//
//  RWtextView.h
//  RWPluginUtilities
//
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>

@interface RWTextView : NSTextView
{
	NSColor* _ignoreBackground;
	NSColor* _htmlBackground;
	BOOL _addedNotificationObserver:1;
}
- (NSArray*)attachments;
- (NSArray*)selectedAttachments;
@end

@interface NSDictionary (RWMarkupDirective)
- (NSString*)tag;
- (NSString*)openTag;
- (NSString*)closeTag;
- (NSString*)name;
- (BOOL)cleartags;
@end

extern NSString* kRWTextViewIgnoreFormattingAttributeName;
extern NSString* kRWTextViewMarkupDirectivesAttributeName;
