//
//  RWAlert.h
//  RWPluginUtilities
//
//  Created by Simon Taylor on 08/05/2005.
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>


@interface RWAlert : NSObject {

}

+ (int)runInfoAlert:(NSString*)title message:(NSString*)message;
+ (int)runInfoAlertOKCancel:(NSString*)title message:(NSString*)message;
+ (int)runInfoAlertOKCancelAlternate:(NSString*)title message:(NSString*)message alternate:(NSString*)alternate;

@end
