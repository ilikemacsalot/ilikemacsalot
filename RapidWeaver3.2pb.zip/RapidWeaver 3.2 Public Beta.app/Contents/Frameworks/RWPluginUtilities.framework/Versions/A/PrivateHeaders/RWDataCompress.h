//
//  RWDataCompress.h
//  RWPluginUtilities
//
//  Created by Simon Taylor on 29/04/2005.
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>


@interface NSData (RWDataCompress)
- (NSData*)compress;
@end
