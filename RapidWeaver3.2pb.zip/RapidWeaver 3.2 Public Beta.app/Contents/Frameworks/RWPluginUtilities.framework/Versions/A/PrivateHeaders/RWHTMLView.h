//
//  RWHTMLView.h
//  RWPluginUtilities
//
//  Created by Simon Taylor on 19/08/2005.
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>

@class RWLineCountView;

@interface RWHTMLView : NSTextView {
	RWLineCountView* _lineView;
	BOOL _showLineNumbers:1;
	BOOL _wrapHTML:1;
}

- (void)setShowLineNumbers:(BOOL)flag;

@end
