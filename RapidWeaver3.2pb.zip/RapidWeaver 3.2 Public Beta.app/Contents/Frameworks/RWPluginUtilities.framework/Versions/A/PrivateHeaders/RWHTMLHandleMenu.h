//
//  RWHTMLHandleMenu.h
//  RWPluginUtilities
//
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>

@class RWPage;

@interface RWHTMLHandleMenu : NSObject {

}

+ (NSMenu*)htmlHandlersMenu:(RWPage*)page 
					 target:(id)target 
			previewSelector:(SEL)preview 
			  otherSelector:(SEL)other;

@end
