//
//  RWFileReference.h
//  RWPluginUtilities
//
//  Created by Simon Taylor on 09/08/2005.
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>


@interface RWFileReference : NSObject {
@private
	NSString* _path;
	NSMutableData* _alias;
}

+ (RWFileReference*)referenceTo:(NSString*)pathA relativeTo:(NSString*)pathB;

- (NSString*)path;
- (void)setPath:(NSString*)pathA relativeTo:(NSString*)pathB;

- (NSData*)alias;
- (void)setAlias:(NSMutableData*)data;

- (BOOL)pathExists;

- (NSString*)resolveRelativeTo:(NSString*)path;

@end
