//
//  RWMarkupAttributes.h
//  RWPluginUtilities
//
//  Created by Simon Taylor on 18/05/2005.
//  Copyright (c) 2005 Realmac Software. All rights reserved.
//
//  THIS IS A RAPIDWEAVER INTERNAL HEADER FILE AND THE INTERFACES
//  DESCRIBED HERE COULD CHANGE WITHOUT NOTICE 
//

#import <Cocoa/Cocoa.h>


@interface RWMarkupAttributes : NSObject {

}

+ (NSMenu*)setupMarkupMenu;

@end
