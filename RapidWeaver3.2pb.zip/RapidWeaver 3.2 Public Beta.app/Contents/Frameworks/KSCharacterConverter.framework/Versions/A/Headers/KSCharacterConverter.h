//
//  KSCharacterConverter.h
//  KSCharacterConverter
//
//  Created by Andrew Zamler-Carhart on Fri Oct 10 2003.
//  Copyright (c) 2003 KavaSoft. All rights reserved.
//
//  This code remains the property of KavaSoft. No part of it may be 
//  redistributed or sublicensed without KavaSoft's prior written permission.  
//

#import <Cocoa/Cocoa.h>

@interface KSCharacterConverter : NSObject {

}

/* This method converts all non-ASCII characters in an NSMutableString
 * containing HTML code into their HTML-escaped equivalents. 
 * 
 * For example, "é" will be converted to "&eacute;". 
 * 
 * The skipTags flag will cause angle brackets, ampersands, and double 
 * quotes to be ignored. 
 * 
 * If an HTML document with no high-bit characters is encoded with 
 * skipTags set to YES, it will be unchanged. Therefore, it is safe to 
 * call this method repeatedly to encode characters as necessary. 
 * 
 * If skipTags is set to NO, these characters will be encoded. This is 
 * useful if you want to quote HTML code on a web page. 
 */
+ (void) encodeUnicodeForHTML: (NSMutableString *) string skipTags: (BOOL) skipTags;

/* This method converts all HTML-escaped equivalents to their Unicode
 * character values. 
 *
 * For example, "&eacute;" will be converted to "é". 
 */
+ (void) decodeUnicodeFromHTML: (NSMutableString *) string;

@end

@interface NSMutableString (NSMutableStringCharacterConverter)

/* These methods are convenience wrappers that process an NSMutableString. 
 *
 * When encoding, skipTags will be set to YES.
 */
- (void) encodeUnicodeForHTML;
- (void) decodeUnicodeFromHTML;

@end

@interface NSString (NSStringCharacterConverter)

/* These methods are convenience wrappers that return an auto-released NSString. 
 *
 * Note that the returned value will in fact be mutable, so you can safely
 * typecast it as an NSMutableString if you need to.
 * 
 * When encoding, skipTags will be set to YES.
 */
- (NSString *) stringWithUnicodeEncodedForHTML;
- (NSString *) stringWithUnicodeDecodedFromHTML;

@end